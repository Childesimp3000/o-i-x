import React from 'react';
export default class Gra extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            gracz:1,
            pola:Array(9).fill(null),
            poprzedniaTablica:[],
            numerRuchu:0
        }
    
    }
    wygrana(){
        var linie = [
            [0, 1, 2],
            [3, 4, 5],
            [6, 7, 8],
            [0, 3, 6],
            [1, 4, 7],
            [2, 5, 8],
            [0, 4, 8],
            [2, 4, 6],
        ]
        var win = 0
                for (let i = 0; i < linie.length; i++) {
                    const [a, b, c] = linie[i];
                    if (this.state.pola[a] && this.state.pola[a] === this.state.pola[b] && this.state.pola[a] === this.state.pola[c]) {
                      if(this.state.pola[a] == "x"){
                        alert("wygrał gracz 1");
                        win=1
                      }else{
                        alert("wygrał gracz 2");
                        win=2
                      }
                    }
                  }
    }
cofnij(){
    console.log(this.state.poprzedniaTablica)
    var historia=this.state.poprzedniaTablica
    var numer=this.state.numerRuchu
    this.setState({
        pola:historia[numer-1],
        numerRuchu: numer-1
    })
}
historia(){
    var tablica=this.state.pola
    var historia=this.state.poprzedniaTablica
    var numer=this.state.numerRuchu
    numer++
    historia.push(tablica)
    this.setState({
        poprzedniaTablica:historia,
        numerRuchu:numer
    })
}
klikniecie(id){
    console.log(this.state.poprzedniaTablica)
   // console.log(this.state.pola);
    if(this.state.pola[id]==null){
        this.historia()
        if(this.state.gracz==1){
            var tablica=this.state.pola
            tablica[id]="x"
            this.setState({
                gracz:0,
                pola:tablica
            })
        }else{
            var tablica=this.state.pola
            tablica[id]="o"
            this.setState({
                gracz:1,
                pola:tablica
            })
        }
        this.wygrana()
    }else{
        alert("pole zajete");
    }
}
    render()
    {
return(
            <div id="kontener">
                <div id="a0" onClick={()=>this.klikniecie(0)}>
                    {this.state.pola[0]}
                </div>
                <div id="a1" onClick={()=>this.klikniecie(1)}>
                  {this.state.pola[1]}
                </div>
                <div id="a2" onClick={()=>this.klikniecie(2)}>
                  {this.state.pola[2]}    
                </div>
                <div id="a3" onClick={()=>this.klikniecie(3)}>
                   {this.state.pola[3]}    
                </div>
                <div id="a4" onClick={()=>this.klikniecie(4)}>
                    {this.state.pola[4]}
                </div>
                <div id="a5" onClick={()=>this.klikniecie(5)}>
                    {this.state.pola[5]}
                </div>
                <div id="a6" onClick={()=>this.klikniecie(6)}>
                    {this.state.pola[6]}
                </div>
                <div id="a7" onClick={()=>this.klikniecie(7)}>
                    {this.state.pola[7]}
                </div>
                <div id="a8" onClick={()=>this.klikniecie(8)}>
                    {this.state.pola[8]}
                </div>
                <div id="his" onClick={()=>this.cofnij()}>
                    numer ruchu: {this.state.numerRuchu}
                </div>
            </div>
        )
    }
}
// dlaczego nie dziala wygrana i hisotria dziwnie